(function(){browser.runtime.onMessage.addListener((function(){console.log("Hello from the background")}))})();
//# sourceMappingURL=background.js.map